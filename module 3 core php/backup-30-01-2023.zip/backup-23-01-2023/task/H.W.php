<?php 
// w.a.p to check a number is odd or even take input from users
// w.a.p to check compound interest take input from users
// w.a.p to check simple interest take input from users
// w.a.p to check area of circle take input from users
// w.a.p to check area of rectangle take input from users
// w.a.p to check average marks in three subject take input from users
                //  math=86
                //  checmistry=90
                //  computer=98

//w.a.p to check max numbers among three numbers  take input from users 
//w.a.p to swap two numbers without using thrd variables  take input from users 
//w.a.p to check a years is leap years or not take input from users 
//w.a.p to check square, qube of any numbers take input from users 


?>