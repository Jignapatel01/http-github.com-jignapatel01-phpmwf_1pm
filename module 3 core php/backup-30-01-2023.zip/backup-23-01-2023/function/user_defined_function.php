<?php 
function test()
{
    $name="My name is Dixit";
    echo $name;
}
test();
?>