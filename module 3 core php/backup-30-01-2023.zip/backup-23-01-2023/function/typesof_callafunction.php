<?php 
/* call a function
           a)call by value
           b) call by reference
 */
?>