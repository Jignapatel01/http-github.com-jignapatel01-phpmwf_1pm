<?php 
/* types of function :
         a) user defined function
         b) inbuild function 
*/
?>