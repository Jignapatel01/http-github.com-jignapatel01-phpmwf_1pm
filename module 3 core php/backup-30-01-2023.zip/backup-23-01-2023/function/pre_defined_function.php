<?php 
// data type : which type of values stored in variables i.e called datatype.
        //   integer, float, string , biginteger
//predefined function :
 // var_dump() : This is a inbuild function that is used to tell us about variables all datat types and descriptions


$name="hi i am jigna"; //string
$name1='65454';        // string 
$a=1023121;           // integer
$b=212.54154;         //float

// echo $name."<br>";
// echo var_dump($name)."<br>";
// echo var_dump($name1)."<br>";
// echo var_dump($a)."<br>";
// echo var_dump($b)."<br>";
var_dump($name);

?>