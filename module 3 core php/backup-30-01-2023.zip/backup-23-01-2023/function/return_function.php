<?php 
function nm()
{
    $name="Hi Dixit radadiya";
    return $name;
}
echo nm();

?>