<?php 
function sum($a,$b)
{

    $c=$a=$b;
    echo "Additions of numbers is :".$c;
}
sum(10,20);
?>