<?php 
/* 
function : A function is a block of code or group of code that can be used to complete any task that is called function.

how to declare function 
syntax : 
function functionname()
{
    statements;
}
call a function
*/
//name print
// $name="hi miten";
// echo $name;

function nm()
{
    $name="Hi i am Miten";
    echo $name;
}
nm();


?>