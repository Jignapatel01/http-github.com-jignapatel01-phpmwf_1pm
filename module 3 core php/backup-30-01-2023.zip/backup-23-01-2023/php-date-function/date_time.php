<?php 
date_default_timezone_set("Asia/calcutta");
echo "Today the date and time is :".date("d/m/Y H:i:s a")."<br>";
echo "Today the date and time is :".date("d/m/Y h:i:s a");

?>