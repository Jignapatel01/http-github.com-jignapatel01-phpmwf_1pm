<?php 
echo "Today is :".date('d/m/y')."<br>";
echo "Today is :".date('d.m.y')."<br>";
echo "Today is :".date('d-m-y')."<br>";

echo "Today is :".date('d-m-Y')."<br>";
echo "today is Month:".date("F")."<br>";
echo "today day is:".date("l")."<br>";
echo "today day is:".date("D")."<br>";


?>