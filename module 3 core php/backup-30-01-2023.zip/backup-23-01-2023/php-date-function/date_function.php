<?php 
/* date function : date function is an inbuild function of php i.e used to print current date | functure date and past date and time of systems
  types of date function 
      a) date()
      b) strtotime()
      c) mktime()
      d) time()
   
*/

?>