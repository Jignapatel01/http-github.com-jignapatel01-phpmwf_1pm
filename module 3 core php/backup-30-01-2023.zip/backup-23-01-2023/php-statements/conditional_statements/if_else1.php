<?php 
// W.A.P rto check a number is odd or even
$num=13;
if($num%2==0)
{
    echo "<h2>Number is Even</h2>";
}
else 
{
    echo "<h2>Number is Odd</h2>";
}

?>