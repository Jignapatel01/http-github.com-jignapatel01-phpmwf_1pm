<?php 

echo "<h3 align='center'>Square of numbers 2 is :".pow(2,2)."</h3>";
echo "<h3 align='center'>qube of numbers 2 is :".pow(2,3)."</h3>";
?>