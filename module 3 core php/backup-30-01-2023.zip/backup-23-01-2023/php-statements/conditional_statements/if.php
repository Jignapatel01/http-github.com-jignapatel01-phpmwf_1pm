<?php 
// if : if is executed when condition is trure
// syntax 
// if(condition)
// {
//     statements;
// } 

$a=10;
$b=5;
if($a>$b)
{
    echo "<h2>A is greter than B</h2>";
}

?>