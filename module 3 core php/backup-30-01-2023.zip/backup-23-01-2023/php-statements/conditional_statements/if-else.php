<?php 
// if : if is executed when condition is trure if condition is flase else is executed
// syntax 
// if(condition)
// {
//     statements;
// } 
// else 
// {
//     statemets;
// }

$a=10;
$b=15;
if($a>$b)
{
    echo "<h2>A is greter than B</h2>";
}
else 
{
    echo "<h2>B is greter than A</h2>";

}

?>