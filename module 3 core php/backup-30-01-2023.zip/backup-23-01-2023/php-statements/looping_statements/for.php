<?php 
/*
 for : for loop is used to print again and again or numbers of rpetations of values

 sytax  

  for(intialization;condition;increment/decrement)
  {
    statements;
  }

*/
$i=50;
for($i=1;$i<=50;$i++)
{
    echo $i."<br>";
}

?>