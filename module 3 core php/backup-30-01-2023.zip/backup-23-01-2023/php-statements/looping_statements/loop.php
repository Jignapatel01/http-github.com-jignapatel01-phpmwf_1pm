<?php 
/* number of iteration or condition repeat again and again there we used loop

   types of loop  in php 
   for()
   foreach()
   while()
   do while()
   
*/



?>