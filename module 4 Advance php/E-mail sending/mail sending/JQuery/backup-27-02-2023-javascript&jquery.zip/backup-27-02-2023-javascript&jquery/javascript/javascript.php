<?php 
// what is javascript  :
javascript is a clent side scripting language 
javascript is load on user browswer
javascript is a prigraming languge 
javascript is used some events onclick , onsubmit, onchange etc. 
javascript used function , operator, variable and conditions etc. 
javascript is a case senstve language 
javascript used some output method to prind javascript 
  a)doument.write()
  b)document.getElementById();
  c)window.print 
  d)alert()
  e)confirm()
  f)prompt()

javascript is called in <body> and <head> both
javascript is called inside of <script> tag 


?>