<script>
var a=10;
var b=50;
var c=a+b;
document.write("Additions of numbers is :",c);

</script>


