<?php 
$state_list=array("gj"=>"gujrat","up"=>"uttar pradesh","mp"=>"madhya pradesh","rj"=>"rajsthan","mh"=>"mahrastra");
//print_r($country_list);
echo json_encode($state_list);

?>