<?php 
$city_list=array("vns"=>"varansi","lko"=>"lucknow","mz"=>"mirzapur","agr"=>"agra","nd"=>"noida","rjt"=>"rajkot","ahd"=>"ahemdabad");
//print_r($country_list);
echo json_encode($city_list);

?>