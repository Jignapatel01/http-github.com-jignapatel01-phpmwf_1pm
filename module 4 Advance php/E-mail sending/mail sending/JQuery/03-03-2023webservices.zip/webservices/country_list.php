<?php 
$country_list=array("ind"=>"india","usa"=>"united state of america","er"=>"europe","jpn"=>"japan","uk"=>"united kingdom",);
//print_r($country_list);
echo json_encode($country_list);

?>